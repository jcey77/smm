-- Jalankan seluruh SQL ini di Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text, display_name text,
 role text not null default 'member' check (role in ('member','silucu','sigemoi','sikecil','admin','owner')),
 created_at timestamptz not null default now()
);
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null, price numeric(14,2) not null default 0 check(price>=0),
 stock integer not null default 0 check(stock>=0), image_url text, note text default '',
 is_visible boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.store_settings (
 id integer primary key default 1 check(id=1), store_name text not null default 'kedai nayau''s',
 low_stock_threshold integer not null default 3 check(low_stock_threshold>=0),
 welcome_text text default '', special_feature boolean not null default false
);
create table if not exists public.payment_settings (
 id integer primary key default 1 check(id=1), enable_ovo boolean not null default false,
 enable_gopay boolean not null default false, enable_qris boolean not null default false,
 ovo_number text default '', gopay_number text default '', payment_name text default '',
 wa_number text default '62895324866749', telegram_username text default '',
 qris_image text default '', payment_image text default ''
);
alter table public.payment_settings add column if not exists payment_image text default '';

insert into public.store_settings(id) values(1) on conflict do nothing;
insert into public.payment_settings(id) values(1) on conflict do nothing;

create or replace function public.is_store_owner()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='owner'); $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin
 insert into public.profiles(id,email,display_name,role)
 values(new.id,new.email,coalesce(new.raw_user_meta_data->>'display_name','member'),'member')
 on conflict(id) do nothing; return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.store_settings enable row level security;
alter table public.payment_settings enable row level security;

drop policy if exists "profiles read self or owner" on public.profiles;
create policy "profiles read self or owner" on public.profiles for select using(id=auth.uid() or public.is_store_owner());
drop policy if exists "profiles update owner only" on public.profiles;
create policy "profiles update owner only" on public.profiles for update using(public.is_store_owner()) with check(public.is_store_owner());

drop policy if exists "public read visible products" on public.products;
create policy "public read visible products" on public.products for select using(is_visible=true or public.is_store_owner());
drop policy if exists "owner manage products" on public.products;
create policy "owner manage products" on public.products for all using(public.is_store_owner()) with check(public.is_store_owner());

drop policy if exists "public read store settings" on public.store_settings;
create policy "public read store settings" on public.store_settings for select using(true);
drop policy if exists "owner manage store settings" on public.store_settings;
create policy "owner manage store settings" on public.store_settings for all using(public.is_store_owner()) with check(public.is_store_owner());

drop policy if exists "public read payment settings" on public.payment_settings;
create policy "public read payment settings" on public.payment_settings for select using(true);
drop policy if exists "owner manage payment settings" on public.payment_settings;
create policy "owner manage payment settings" on public.payment_settings for all using(public.is_store_owner()) with check(public.is_store_owner());

-- Bucket publik untuk gambar QRIS/payment. Upload hanya owner.
insert into storage.buckets(id,name,public) values('store-media','store-media',true) on conflict(id) do update set public=true;
drop policy if exists "public read store media" on storage.objects;
create policy "public read store media" on storage.objects for select using(bucket_id='store-media');
drop policy if exists "owner upload store media" on storage.objects;
create policy "owner upload store media" on storage.objects for insert with check(bucket_id='store-media' and public.is_store_owner());
drop policy if exists "owner update store media" on storage.objects;
create policy "owner update store media" on storage.objects for update using(bucket_id='store-media' and public.is_store_owner()) with check(bucket_id='store-media' and public.is_store_owner());
drop policy if exists "owner delete store media" on storage.objects;
create policy "owner delete store media" on storage.objects for delete using(bucket_id='store-media' and public.is_store_owner());

-- Setelah akun owner berhasil daftar, ganti email di bawah lalu jalankan SATU KALI:
-- update public.profiles set role='owner' where email='EMAIL_OWNER_KAMU';

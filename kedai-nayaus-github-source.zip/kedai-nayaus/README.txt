KEDAI NAYAU'S — PETUNJUK PASANG DI GITHUB PAGES

ISI ZIP
- index.html : halaman web
- style.css  : desain pink soft, mobile friendly
- app.js     : fitur login, produk, stok, payment, owner
- supabase.sql : database + keamanan
- assets/mascot.png : taruh gambar maskot yang kamu upload di sini (lihat langkah 1)

1. MASKOT
Buat folder bernama assets di repository GitHub, lalu upload foto karakter yang kamu kirim dan beri nama mascot.png.
Jangan mengubah file index.html; halaman akan otomatis menampilkan gambar itu.

2. SUPABASE (agar data tidak hilang dan tersinkron di HP lain)
- Buka project Supabase yang ingin dipakai.
- Masuk SQL Editor > New query.
- Buka file supabase.sql, salin semua isinya, lalu Run.
- Buka Project Settings > API. Salin Project URL dan publishable key (atau anon public key).
- Buka app.js. Ganti:
  PASTE_SUPABASE_URL
  PASTE_SUPABASE_PUBLISHABLE_OR_ANON_KEY
  dengan milik project kamu.
- Jangan pernah pakai service_role key di website.

3. OWNER
- Buka website, pilih Daftar dan buat akun memakai email owner.
- Setelah daftar, login.
- Di Supabase > Table Editor > profiles, cari email owner kamu dan ubah kolom role menjadi owner.
  Alternatif: di SQL Editor jalankan:
  update public.profiles set role='owner' where email='EMAIL_KAMU';
- Logout lalu login kembali. Menu Owner Studio akan muncul.
- Password akun owner dikelola oleh Supabase Auth. Jangan menanam password owner di file JavaScript karena pengunjung bisa membacanya.
- Password "sheyya221" yang kamu sebut bisa dipakai sebagai password akun saat membuat akun owner, tetapi sebaiknya gunakan password unik yang kuat dan jangan bagikan.

4. UPLOAD KE GITHUB PAGES
- Ekstrak ZIP.
- Upload index.html, style.css, app.js, supabase.sql, README.txt ke repository.
- Upload folder assets beserta mascot.png.
- Repository Settings > Pages > Deploy from a branch > main > /(root) > Save.
- Tunggu sampai GitHub Pages selesai deploy.

5. FITUR
- Tambah/edit/hapus produk, harga, note, gambar, stok.
- Tambah/kurangi stok, tampil/sembunyikan produk, notifikasi stok rendah di Owner Studio.
- Login/daftar member dan pengaturan role.
- Aktif/nonaktif OVO, GoPay, QRIS; nomor pembayaran; foto QRIS dan gambar payment.
- Upload gambar QRIS/payment ke Supabase Storage (bucket store-media dibuat oleh SQL).
- Pengaturan nama toko, sambutan, batas stok rendah, dan fitur special.
- Tombol order WhatsApp menuju nomor 62895324866749 dengan teks "hii kak! mau order..".

CATATAN PENTING
- Tanpa Supabase, website hanya memakai localStorage demo di perangkat yang sama; data tidak tersinkron ke HP lain.
- Pembayaran di versi ini manual: website menampilkan metode dan gambar pembayaran, bukan verifikasi/auto payment.
- Pastikan akun owner dibuat dan role diubah menjadi owner. Jangan pernah memberi role owner kepada member biasa.

/* Kedai Nayau's — Supabase-backed storefront.
   Masukkan URL project dan publishable/anon key milikmu di bawah.
   Jangan pernah memasukkan service_role key ke website publik. */
const SUPABASE_URL = "https://iprysphevioraubkgqhw.supabase.co";
const SUPABASE_ANON_KEY = "PASTE_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
const sbReady = window.supabase && SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const db = sbReady ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = id => document.getElementById(id);
let session=null, profile=null, products=[], settings={}, payments={}, registerMode=false, stockAction="add";
const money=n=>"Rp "+Number(n||0).toLocaleString("id-ID");
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(s){$("toast").textContent=s;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2600)}
function modal(id,show=true){$(id).classList.toggle("hidden",!show)}
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>modal(b.dataset.close,false));
function waLink(text="hii kak! mau order.."){return "https://wa.me/"+String(payments.wa_number||"62895324866749").replace(/\D/g,"")+"?text="+encodeURIComponent(text)}
function needDb(){if(!db){toast("Hubungkan Supabase dulu. Ikuti README di folder project ya.");return true}return false}
async function refresh(){
 if(!db){products=JSON.parse(localStorage.getItem("kn_products")||"[]");settings=JSON.parse(localStorage.getItem("kn_settings")||"{}");payments=JSON.parse(localStorage.getItem("kn_payments")||"{}");renderAll();return}
 const [p,s,pay]=await Promise.all([db.from("products").select("*").order("created_at",{ascending:false}),db.from("store_settings").select("*").eq("id",1).maybeSingle(),db.from("payment_settings").select("*").eq("id",1).maybeSingle()]);
 if(p.error)console.error(p.error);products=p.data||[];settings=s.data||{};payments=pay.data||{};renderAll();
}
async function loadProfile(){profile=null;if(!db||!session){updateAuth();return}const {data,error}=await db.from("profiles").select("*").eq("id",session.user.id).maybeSingle();if(error)console.error(error);profile=data;updateAuth()}
function updateAuth(){
 $("authOpen").classList.toggle("hidden",!!session);$("logoutBtn").classList.toggle("hidden",!session);
 $("ownerPanel").classList.toggle("hidden",profile?.role!=="owner");
 if(session&&profile)$("authOpen").textContent=profile.display_name||session.user.email;
}
function renderAll(){renderProducts();renderPayments();$("productCount").textContent=products.filter(p=>p.is_visible&&p.stock>0).length; if(profile?.role==="owner")renderOwnerProducts()}
function renderProducts(){
 const q=$("searchInput").value.toLowerCase();
 const arr=products.filter(p=>p.is_visible&&p.stock>0&&(`${p.name} ${p.note||""}`).toLowerCase().includes(q));
 $("productGrid").innerHTML=arr.length?arr.map(p=>`<article class="product-card"><div class="product-image">${p.image_url?`<img src="${esc(p.image_url)}" alt="${esc(p.name)}" loading="lazy" onerror="this.parentElement.textContent='୨୧'">`:"୨୧"}</div><h3>${esc(p.name)}</h3><p class="product-note">${esc(p.note||"Premium service untuk kamu ♡")}</p><div class="product-meta"><span class="price">${money(p.price)}</span><span class="stock">Stok ${p.stock}</span></div><a class="btn btn-primary" href="${waLink("hii kak! mau order.. "+p.name)}" target="_blank" rel="noreferrer">Pesan sekarang ↗</a></article>`).join(""):`<div class="empty-state">Belum ada produk yang tersedia. ♡</div>`;
}
function renderPayments(){
 let a=[];
 if(payments.enable_ovo)a.push(`<div class="payment-card"><b>OVO</b><span>${esc(payments.ovo_number||"Nomor belum diatur")}</span></div>`);
 if(payments.enable_gopay)a.push(`<div class="payment-card"><b>GoPay</b><span>${esc(payments.gopay_number||"Nomor belum diatur")}</span></div>`);
 if(payments.enable_qris)a.push(`<div class="payment-card"><b>QRIS</b><span>${esc(payments.payment_name||"Scan untuk membayar")}</span>${payments.qris_image?`<img src="${esc(payments.qris_image)}" alt="QRIS">`:""}</div>`);
 if(payments.payment_image)a.push(`<div class="payment-card"><b>Payment info</b><img src="${esc(payments.payment_image)}" alt="Gambar payment"></div>`);
 $("paymentList").innerHTML=a.length?a.join(""):`<div class="empty-state">Metode pembayaran akan ditampilkan di sini. ♡</div>`;
 $("mainWa").href=waLink();$("welcomeText").textContent=settings.welcome_text||"Temukan kebutuhan premium favoritmu di sini. Order gampang, pelayanan hangat!";
 $("brandName").textContent=settings.store_name||"kedai nayau's";document.title=(settings.store_name||"kedai nayau's")+" ♡";
 $("heroTitle").innerHTML=(settings.special_feature?`a little special<br><em>for your day.</em>`:`a little sweetness<br><em>for your day.</em>`);
}
function renderOwnerProducts(){
 $("ownerProducts").innerHTML=products.length?products.map(p=>`<div class="owner-row"><div><strong>${esc(p.name)} ${p.is_visible?"":"· disembunyikan"}</strong><small>${money(p.price)} · stok ${p.stock} · ${esc(p.note||"Tanpa note")}</small></div><div class="owner-actions"><button class="mini-btn" onclick="editProduct('${p.id}')">Edit</button><button class="mini-btn" onclick="openStock('${p.id}')">Stok ±</button><button class="mini-btn" onclick="toggleVisible('${p.id}',${!p.is_visible})">${p.is_visible?"Sembunyikan":"Tampilkan"}</button><button class="mini-btn danger" onclick="deleteProduct('${p.id}')">Hapus</button></div></div>`).join(""):`<div class="empty-state">Belum ada produk. Tambahkan produk pertamamu!</div>`;
 const threshold=Number(settings.low_stock_threshold??3), alerts=products.filter(p=>p.stock<=threshold);
 $("stockAlerts").innerHTML=alerts.length?alerts.map(p=>`<div class="alert-line">♡ ${esc(p.name)} — stok tersisa ${p.stock}</div>`).join(""):`<span>Semua stok aman. Tidak ada peringatan saat ini.</span>`;
}
function fillPaymentForm(){
 $("payOvo").checked=!!payments.enable_ovo;$("payGopay").checked=!!payments.enable_gopay;$("payQris").checked=!!payments.enable_qris;
 $("ovoNumber").value=payments.ovo_number||"";$("gopayNumber").value=payments.gopay_number||"";$("paymentName").value=payments.payment_name||"";
 $("qrisImage").value=payments.qris_image||"";$("paymentImage").value=payments.payment_image||"";$("waNumber").value=payments.wa_number||"62895324866749";$("telegramUser").value=payments.telegram_username||"";
 $("storeName").value=settings.store_name||"kedai nayau's";$("lowStock").value=settings.low_stock_threshold??3;$("welcomeEdit").value=settings.welcome_text||"";$("specialFeature").checked=!!settings.special_feature;
}
async function uploadImage(file,folder){
 if(!file)return null;if(!db){toast("Upload gambar perlu koneksi Supabase.");return null}
 const safe=file.name.toLowerCase().replace(/[^a-z0-9.-]/g,"-"),path=folder+"/"+Date.now()+"-"+safe;
 const {error}=await db.storage.from("store-media").upload(path,file,{upsert:true,contentType:file.type});
 if(error){toast("Upload gagal: "+error.message);return null}
 const {data}=db.storage.from("store-media").getPublicUrl(path);return data.publicUrl;
}
async function saveRow(table,payload){const {error}=await db.from(table).upsert(payload);if(error)toast(error.message);return !error}
$("authOpen").onclick=()=>{registerMode=false;setAuthMode();modal("authModal")};
$("switchAuthBtn").onclick=()=>{registerMode=!registerMode;setAuthMode()};
function setAuthMode(){$("authTitle").textContent=registerMode?"Daftar akun":"Login";$("authSubmit").textContent=registerMode?"Daftar":"Login";$("switchAuth").firstChild.textContent=registerMode?"Sudah punya akun? ":"Belum punya akun? ";$("switchAuthBtn").textContent=registerMode?"Login":"Daftar";$("authMessage").textContent=""}
$("authForm").onsubmit=async e=>{
 e.preventDefault();if(needDb())return;const email=$("authEmail").value.trim(),password=$("authPassword").value;
 const res=registerMode?await db.auth.signUp({email,password,options:{data:{display_name:email.split("@")[0]}}}):await db.auth.signInWithPassword({email,password});
 if(res.error){$("authMessage").textContent=res.error.message;return}
 if(registerMode){$("authMessage").textContent="Akun dibuat. Cek email jika verifikasi diminta, lalu login.";return}
 session=res.data.session;await loadProfile();await refresh();modal("authModal",false);toast("Login berhasil ♡");
};
$("logoutBtn").onclick=async()=>{if(db)await db.auth.signOut();session=null;profile=null;updateAuth();toast("Kamu sudah logout")};
$("addProductBtn").onclick=()=>{if(profile?.role!=="owner")return;$("productForm").reset();$("editProductId").value="";$("prodVisible").checked=true;$("productModalTitle").textContent="Tambah produk";modal("productModal")};
window.editProduct=id=>{if(profile?.role!=="owner")return;const p=products.find(x=>x.id===id);if(!p)return;$("productForm").reset();$("editProductId").value=p.id;$("prodName").value=p.name;$("prodPrice").value=p.price;$("prodStock").value=p.stock;$("prodImage").value=p.image_url||"";$("prodNote").value=p.note||"";$("prodVisible").checked=p.is_visible;$("productModalTitle").textContent="Edit produk";modal("productModal")};
$("productForm").onsubmit=async e=>{
 e.preventDefault();if(profile?.role!=="owner")return;const id=$("editProductId").value,payload={name:$("prodName").value.trim(),price:Number($("prodPrice").value),stock:Number($("prodStock").value),image_url:$("prodImage").value.trim()||null,note:$("prodNote").value.trim(),is_visible:$("prodVisible").checked};
 if(db){const res=id?await db.from("products").update(payload).eq("id",id):await db.from("products").insert(payload);if(res.error){$("productMessage").textContent=res.error.message;return}}
 else{if(id)products=products.map(p=>p.id===id?{...p,...payload}:p);else products.unshift({id:crypto.randomUUID(),...payload});localStorage.setItem("kn_products",JSON.stringify(products))}
 modal("productModal",false);await refresh();toast("Produk tersimpan ♡");
};
window.openStock=id=>{if(profile?.role!=="owner")return;$("stockProductId").value=id;$("stockAmount").value=1;$("stockMessage").textContent="";modal("stockModal")};
$("stockForm").onsubmit=async e=>{
 e.preventDefault();if(profile?.role!=="owner")return;stockAction=e.submitter?.dataset.stock||"add";const p=products.find(x=>x.id===$("stockProductId").value);if(!p)return;
 const amount=Number($("stockAmount").value),next=stockAction==="add"?p.stock+amount:p.stock-amount;if(next<0){$("stockMessage").textContent="Stok tidak boleh kurang dari 0.";return}
 if(db){const {error}=await db.from("products").update({stock:next}).eq("id",p.id);if(error){$("stockMessage").textContent=error.message;return}}
 else{p.stock=next;localStorage.setItem("kn_products",JSON.stringify(products))}
 modal("stockModal",false);await refresh();toast("Stok diperbarui ♡");
};
window.toggleVisible=async(id,value)=>{if(profile?.role!=="owner")return;if(db){const {error}=await db.from("products").update({is_visible:value}).eq("id",id);if(error){toast(error.message);return}}else{products.find(p=>p.id===id).is_visible=value;localStorage.setItem("kn_products",JSON.stringify(products))}await refresh();toast("Tampilan produk diperbarui")};
window.deleteProduct=async id=>{if(profile?.role!=="owner"||!confirm("Yakin ingin menghapus produk ini?"))return;if(db){const {error}=await db.from("products").delete().eq("id",id);if(error){toast(error.message);return}}else{products=products.filter(p=>p.id!==id);localStorage.setItem("kn_products",JSON.stringify(products))}await refresh();toast("Produk dihapus")};
$("paymentForm").onsubmit=async e=>{
 e.preventDefault();if(profile?.role!=="owner")return;let qris=$("qrisImage").value.trim(),payment=$("paymentImage").value.trim();
 const qfile=$("qrisFile").files[0],pfile=$("paymentFile").files[0];if(qfile)qris=await uploadImage(qfile,"qris")||qris;if(pfile)payment=await uploadImage(pfile,"payments")||payment;
 const payload={id:1,enable_ovo:$("payOvo").checked,enable_gopay:$("payGopay").checked,enable_qris:$("payQris").checked,ovo_number:$("ovoNumber").value.trim(),gopay_number:$("gopayNumber").value.trim(),payment_name:$("paymentName").value.trim(),qris_image:qris,payment_image:payment,wa_number:$("waNumber").value.trim()||"62895324866749",telegram_username:$("telegramUser").value.trim()};
 if(db){if(!await saveRow("payment_settings",payload))return}else{payments=payload;localStorage.setItem("kn_payments",JSON.stringify(payments))}
 await refresh();toast("Pengaturan payment disimpan ♡");
};
$("settingsForm").onsubmit=async e=>{
 e.preventDefault();if(profile?.role!=="owner")return;const payload={id:1,store_name:$("storeName").value.trim(),low_stock_threshold:Number($("lowStock").value),welcome_text:$("welcomeEdit").value.trim(),special_feature:$("specialFeature").checked};
 if(db){if(!await saveRow("store_settings",payload))return}else{settings=payload;localStorage.setItem("kn_settings",JSON.stringify(settings))}
 await refresh();toast("Pengaturan toko disimpan ♡");
};
async function loadMembers(){
 if(!db||profile?.role!=="owner")return;const {data,error}=await db.from("profiles").select("id,email,display_name,role,created_at").order("created_at",{ascending:false});
 if(error){$("memberList").textContent=error.message;return}
 $("memberList").innerHTML=(data||[]).map(m=>`<div class="owner-row"><div><strong>${esc(m.display_name||m.email||"Member")}</strong><small>${esc(m.email||"")} · ${esc(m.role)}</small></div><select aria-label="Role member" onchange="changeRole('${m.id}',this.value)"><option value="member" ${m.role==="member"?"selected":""}>member</option><option value="silucu" ${m.role==="silucu"?"selected":""}>silucu</option><option value="sigemoi" ${m.role==="sigemoi"?"selected":""}>sigemoi</option><option value="sikecil" ${m.role==="sikecil"?"selected":""}>sikecil</option><option value="admin" ${m.role==="admin"?"selected":""}>admin</option></select></div>`).join("")||`<div class="empty-state">Belum ada member.</div>`;
}
window.changeRole=async(id,role)=>{if(profile?.role!=="owner"||!["member","silucu","sigemoi","sikecil","admin"].includes(role))return;const {error}=await db.from("profiles").update({role}).eq("id",id);if(error){toast(error.message);return}toast("Role diperbarui");loadMembers()};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".tab-panel").forEach(x=>x.classList.toggle("hidden",x.id!==b.dataset.tab));if(b.dataset.tab==="paymentsTab"||b.dataset.tab==="settingsTab")fillPaymentForm();if(b.dataset.tab==="membersTab")loadMembers()});
$("searchInput").oninput=renderProducts;$("year").textContent=new Date().getFullYear();
(async()=>{if(db){const {data}=await db.auth.getSession();session=data.session;await loadProfile();db.auth.onAuthStateChange(async(_event,s)=>{session=s;await loadProfile();await refresh()})}else toast("Mode preview: atur Supabase untuk menyimpan data antar perangkat.");updateAuth();await refresh()})();
